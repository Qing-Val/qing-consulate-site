
import React from "react";

export default function Rules() {
  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">Rules & Regulations</h2>
      <ul className="list-disc list-inside space-y-2 text-md">
        <li><strong>Respect All Members:</strong> Absolutely no harassment, toxicity, or discrimination.</li>
        <li><strong>Follow the Chain of Command:</strong> Orders from superiors must be followed unless unethical.</li>
        <li><strong>Honor the Clan:</strong> Uphold dignity in all in-game and public interactions.</li>
        <li><strong>No Exploits or Cheats:</strong> Zero tolerance policy. Permanent removal upon violation.</li>
        <li><strong>Uniform Code:</strong> Proper attire must be worn during official activities.</li>
        <li><strong>Clan Representation:</strong> Conduct yourself with discipline, in and out of game.</li>
      </ul>
    </section>
  );
}
