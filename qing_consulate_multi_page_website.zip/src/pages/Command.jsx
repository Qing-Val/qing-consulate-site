
import React from "react";

export default function Command() {
  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">Chain of Command</h2>
      <ul className="list-disc list-inside space-y-1 text-md">
        <li><strong>High Consul:</strong> Supreme authority and leader of the Qing Consulate.</li>
        <li><strong>Commanders:</strong> Oversee all military operations and divisions.</li>
        <li><strong>Captains:</strong> Squad leaders responsible for ground operations and order.</li>
        <li><strong>Operatives:</strong> Elite soldiers with advanced training and tactics.</li>
        <li><strong>Initiates:</strong> New recruits undergoing trials and proving their worth.</li>
      </ul>
    </section>
  );
}
