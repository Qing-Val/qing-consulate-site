
import React from "react";

export default function Home() {
  return (
    <section className="text-center space-y-6">
      <h2 className="text-3xl font-bold">Welcome to the Qing Consulate</h2>
      <p className="text-lg">
        A Roblox military clan forged in honor and discipline, rooted in tradition,
        and dedicated to excellence. Our mission is to preserve the power and dignity of the
        Qing legacy through unity and strength.
      </p>
    </section>
  );
}
