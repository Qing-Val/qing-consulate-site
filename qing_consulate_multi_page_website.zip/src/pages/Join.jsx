
import React from "react";

export default function Join() {
  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">Join the Qing Consulate</h2>
      <p className="text-md">
        To enlist in the Qing Consulate, demonstrate loyalty, discipline, and honor. Follow the steps below:
      </p>
      <ol className="list-decimal list-inside space-y-2 text-md">
        <li>Join our official Roblox group.</li>
        <li>Contact a Captain or Commander for recruitment.</li>
        <li>Attend a basic evaluation training session.</li>
        <li>Earn your uniform and begin your service to the Qing legacy.</li>
      </ol>
      <div className="text-center mt-6">
        <a href="#" className="inline-block bg-yellow-500 hover:bg-yellow-400 text-black px-6 py-2 font-bold rounded shadow">
          Join Now
        </a>
      </div>
    </section>
  );
}
