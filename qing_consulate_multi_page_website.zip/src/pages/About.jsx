
import React from "react";

export default function About() {
  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">About Us</h2>
      <p className="text-md">
        The Qing Consulate emulates the ancient power of imperial tradition and military precision.
        We are structured, battle-hardened, and elite. Every member earns their place through skill,
        commitment, and loyalty to the greater vision.
      </p>
    </section>
  );
}
