
import React from "react";

export default function QingConsulateWebsite() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 text-yellow-300 font-serif">
      <header className="bg-black py-8 border-b border-yellow-500 shadow-md">
        <div className="max-w-7xl mx-auto px-4">
          <h1 className="text-5xl font-bold text-center tracking-wider">QING CONSULATE</h1>
          <p className="text-center mt-2 text-lg italic">"Loyalty before all else, except honor."</p>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-10 space-y-16">
        <section id="home" className="text-center space-y-6">
          <h2 className="text-3xl font-bold">Welcome to the Qing Consulate</h2>
          <p className="text-lg">
            A Roblox military clan forged in honor and discipline, rooted in tradition,
            and dedicated to excellence. Our mission is to preserve the power and dignity of the
            Qing legacy through unity and strength.
          </p>
        </section>

        <section id="about" className="space-y-4">
          <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">About Us</h2>
          <p className="text-md">
            The Qing Consulate emulates the ancient power of imperial tradition and military precision.
            We are structured, battle-hardened, and elite. Every member earns their place through skill,
            commitment, and loyalty to the greater vision.
          </p>
        </section>

        <section id="rules" className="space-y-4">
          <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">Rules & Regulations</h2>
          <ul className="list-disc list-inside space-y-2 text-md">
            <li><strong>Respect All Members:</strong> Absolutely no harassment, toxicity, or discrimination.</li>
            <li><strong>Follow the Chain of Command:</strong> Orders from superiors must be followed unless unethical.</li>
            <li><strong>Honor the Clan:</strong> Uphold dignity in all in-game and public interactions.</li>
            <li><strong>No Exploits or Cheats:</strong> Zero tolerance policy. Permanent removal upon violation.</li>
            <li><strong>Uniform Code:</strong> Proper attire must be worn during official activities.</li>
            <li><strong>Clan Representation:</strong> Conduct yourself with discipline, in and out of game.</li>
          </ul>
        </section>

        <section id="command" className="space-y-4">
          <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">Chain of Command</h2>
          <ul className="list-disc list-inside space-y-1 text-md">
            <li><strong>High Consul:</strong> Supreme authority and leader of the Qing Consulate.</li>
            <li><strong>Commanders:</strong> Oversee all military operations and divisions.</li>
            <li><strong>Captains:</strong> Squad leaders responsible for ground operations and order.</li>
            <li><strong>Operatives:</strong> Elite soldiers with advanced training and tactics.</li>
            <li><strong>Initiates:</strong> New recruits undergoing trials and proving their worth.</li>
          </ul>
        </section>

        <section id="join" className="space-y-4">
          <h2 className="text-2xl font-bold border-b border-yellow-500 pb-2">Join the Qing Consulate</h2>
          <p className="text-md">
            To enlist in the Qing Consulate, demonstrate loyalty, discipline, and honor. Follow the steps below:
          </p>
          <ol className="list-decimal list-inside space-y-2 text-md">
            <li>Join our official Roblox group.</li>
            <li>Contact a Captain or Commander for recruitment.</li>
            <li>Attend a basic evaluation training session.</li>
            <li>Earn your uniform and begin your service to the Qing legacy.</li>
          </ol>
          <div className="text-center mt-6">
            <a href="#" className="inline-block bg-yellow-500 hover:bg-yellow-400 text-black px-6 py-2 font-bold rounded shadow">
              Join Now
            </a>
          </div>
        </section>
      </main>

      <footer className="bg-black text-center text-sm py-6 border-t border-yellow-500">
        © 2025 Qing Consulate. All rights reserved.
      </footer>
    </div>
  );
}
